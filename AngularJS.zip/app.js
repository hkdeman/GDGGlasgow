var app1 = angular.module('app1',[]);

var tokenKey = "todo_list";

app1.controller('todoCtrl',function($scope) {
	$scope.todo = [];	
	if(localStorage.getItem(tokenKey)==null) {
		localStorage.setItem(tokenKey, JSON.stringify($scope.todo));		
	} else {
		$scope.todo = JSON.parse(localStorage.getItem(tokenKey));
	}
	$scope.task = "Default Task";
	$scope.addTask = function() {
		$scope.todo.push($scope.task);
		localStorage.setItem(tokenKey, JSON.stringify($scope.todo));		
	};

	$scope.removeTask = function(index) {
		$scope.todo.splice(index,1);
		localStorage.setItem(tokenKey, JSON.stringify($scope.todo));		
	}
});
